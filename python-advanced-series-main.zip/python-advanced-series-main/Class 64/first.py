#!/usr/bin/env python
# coding: utf-8

# In[2]:


def greet():
    print("good morning")

def message():
    print("have a nice day")

    
def main():
    greet()
    message()
main()

print("first:",__name__)


# In[6]:


def greet():
    print("good morning")

def message():
    print("have a nice day")

    
def main():
    greet()
    message()
    
if __name__ =="__main__":
    main()

print("first:",__name__)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




