#!/usr/bin/env python
# coding: utf-8

# In[6]:


import first
first.greet() 


# In[ ]:


def greeting():
    greeting()
    print("good afternoon")

def message():
    print("how are you")
    
def main():
    greeting()
    message()
main()

print(__name__)

