#!/usr/bin/env python
# coding: utf-8

# In[2]:


print("demo1:",__name__)

