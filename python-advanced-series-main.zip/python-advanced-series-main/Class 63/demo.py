#!/usr/bin/env python
# coding: utf-8

# In[1]:


def test():
    print("hai")


# In[ ]:


def add(a,b):
    print(a+b)
    
def sub(a,b):
    print(a-b)
    
def mul(a,b):
    print(a*b)
    
def div(a,b):
    print(a/b)

