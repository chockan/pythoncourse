#!/usr/bin/env python
# coding: utf-8

# In[1]:


def test():
    print("i am from demo 2")

