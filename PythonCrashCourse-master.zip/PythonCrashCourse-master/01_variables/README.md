# Variables
## Variables helps us to store key&value information that we would like to refer to its value throughout the program
```python 
name = "Michael"
age = 30

print(name, "is my name")
print(name, "is", age, "years old")
print(name, "likes to eat pizza")
print("This man's name is", name)



```
## Exercise:

### Is there a way that you can create more than one variable in one line of code ? Worth to search on web if this could be done!

### Answer:
```python
a, b, c = 1,2,3 # a will receive 1, b will receive 2, c will receive 3
#More examples:
print(a)
print(b)
print(c)

name, age = "Jim", 25
print(name)
print(age)
```
