#Variables

#Variables helps us to store key&value information that we would like to refer to its value throughout the program


name = "Michael"
age = 30

print(name, "is my name")
print(name, "is", age, "years old")
print(name, "likes to eat pizza")
print("This man's name is", name)


