#Instance Methods

#You can create various methods to execute on your instances of a class
#