#Math Operators

#Most of the known arithmetic operations are available to use like in real life math


#type() - A built-in function that will give us back the
#type of a specific variable

# Addition - 3 + 2
# Subtraction - 3 + 2
# Division - 3 / 2 (Will return float)
# Division without Remainder - 3 // 2
# Multiply - 3 * 2
# Power - 3 ** 2
# Modulus - 3 % 2


action = 3 + 2 # Change the operation to what you want to test out
print(f'Result is: {action}')