## Exercise 11 - Drink Water Reminder
Write a python program which reminds you of drinking water every hour or two. Your program can either beep or send desktop notifications for a specific operating system
## [Next Lesson>>](https://replit.com/@codewithharry/95-Day-95-Regular-Expressions)