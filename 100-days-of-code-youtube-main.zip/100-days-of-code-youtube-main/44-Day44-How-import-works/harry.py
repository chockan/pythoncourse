def welcome():
  print("Hey you are welcome my friend")


harry = "A good boy"