Create a program capable of displaying questions to the user like KBC. 
Use List data type to store the questions and their correct answers.
Display the final amount the person is taking home after playing the game.
## [Next Lesson>>](https://replit.com/@codewithharry/28-Day28-f-strings)