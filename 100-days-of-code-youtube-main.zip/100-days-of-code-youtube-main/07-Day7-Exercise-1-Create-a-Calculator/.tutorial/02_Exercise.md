## Exercise 1 - Create a Calculator
Create a calculator capable of performing addition, subtraction, multiplication and division operations on two numbers. Your program should format the output in a readable manner!

## [Next Lesson>>](https://replit.com/@codewithharry/08-Day8-Exercise-1-Create-a-Calculator-Solution#main.py)