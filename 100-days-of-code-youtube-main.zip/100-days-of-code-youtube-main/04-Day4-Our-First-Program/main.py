print("Hello World", 7)
print(5)
print("Bye")
print(17*13)