#Exercise 10
Use the NewsAPI and the requests module to fetch the daily news related to different topics. Go to: https://newsapi.org/ and explore the various options to build you application
## [Next Lesson>>](https://replit.com/@codewithharry/94-Day-94-Exercise-11)