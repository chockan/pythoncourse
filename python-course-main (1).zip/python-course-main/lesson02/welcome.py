line01 = "********************"  # header / footer
line02 = "*                  *"  # re-use
line03 = "*     WELCOME!     *"


# starts with a blank line
print('')
print(line01)
print(line02)
print(line03)
print(line02)
print(line01)
