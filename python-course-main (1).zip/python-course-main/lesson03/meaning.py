meaning = 42
print('')

# if meaning > 10:
#     print('Right on!')
# else:
#     print('Not today')

# Ternary Operator
print('Right on!') if meaning > 10 else print('Not today')
