# Minesweeper Game
The classic Minesweeper game in python. 

## Library used
`import random` and `import re`

## How to run the script
`python minesweeper.py`

## Screenshot
<img src="./images/1_ss.png" alt="pic1" />
<img src="./images/2_ss.png" alt="pic1" />

## *Author Name*
[`Subhadeep Das(Raven1233)`](https://github.com/Raven1233)