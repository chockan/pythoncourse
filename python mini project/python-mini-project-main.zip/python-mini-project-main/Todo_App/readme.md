Todo App Done with Flask 

This is a simple todo app created to foster the understanding of the fundamentals of Flask.


Requirements: 
  flask-bootstrap, do pip install flask-bootstrap
