# Minion Game >>

    The Terminal playable sub string game that deal with count of vowel and constituent, score will be based on some following rules.

# Rules
    firstly we have to take input of capital String/single word without spaces

        game rules:
        1) Both players are given the same string, .
        2) Both players have to make substrings using the letters of the string .
        3) Stuart has to make words starting with consonants.
        4) Kevin has to make words starting with vowels.
        5) The game ends when both players have made all possible substrings.

        A player gets +1 point for each occurrence of the substring in the string .

### Prerequisites
    nothig just check is python is installed locally in youe device

### How to run the script
    windows : just click on run button


## *Author Name*

[Prafull Sonawane](https://github.com/prafuel)