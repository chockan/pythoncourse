
# Class of the nodes

class Node:
    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data

