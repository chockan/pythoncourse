# Script Title
The text encryptor is a python mini project that allows the user to encrypt or decrypt any tet they wish using the ceaser cipher... With no GUI, it may not be the most intuitive, but I would like if someone could contribute and make a gui for this application in the future...

### Prerequisites
Do not worry... there are no modules that are needed to run the project... just python itself...

### How to run the script
just run the script and follow the instructions

### Screenshot/GIF showing the sample use of the script
image.png

## *Author Name*
BlockmasterPlayz