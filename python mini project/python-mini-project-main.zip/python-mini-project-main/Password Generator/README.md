# Password Generator
Create secure passwords that are impossible to crack.

## Libraly used
`import random` and `import tkinter and import pyperclip`
for install pyperclip
`pip install pyperclip`

## How to run the script
`python password_generator.py`

## Screenshot
<div align="center"><img src="https://user-images.githubusercontent.com/50146617/146649143-0b00e222-7b99-4d98-96c5-7d2040e00560.png"></div>
<div align="center"><img src="https://user-images.githubusercontent.com/50146617/146649273-2b7263f3-5fdc-41e8-8cb6-538db2933c0a.png"></div>

## *Author Name*
[`Pargorn Ruasijan (xNewz)`](https://github.com/xNewz)
