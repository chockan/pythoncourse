<!--Please do not remove this part-->

![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)
[![View My Profile](https://img.shields.io/badge/View-My_Profile-green?logo=GitHub)](https://github.com/FH089)

# Zombie Game

<p align="center">
<img src="https://images.unsplash.com/photo-1637858868799-7f26a0640eb6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=580&q=80" width=50% height=50%>

<!--An image is an illustration for your project, the tip here is using your sense of humour as much as you can :D

You can copy paste my markdown photo insert as following:
<p align="center">
<img src="your-source-is-here" width=40% height=40%>
-->

## 🛠️ Description

<!--Remove the below lines and add yours -->

Simple Zombie Survival Quiz Game built with python

## ⚙️ Languages or Frameworks Used

<!--Remove the below lines and add yours -->

The only module required is random. You can install it using
`pip install random`

## 🌟 How to run

<!--Remove the below lines and add yours -->

It is really simple to run the game. Simple head over to the directory where python file is saved and run the following command:
`python zombie.py`

## 📺 Demo

<p align="center">
<img src="https://github.com/ndleah/python-mini-project/blob/main/IMG/zombie_game_demo.png" width=70% height=70%>

## 🤖 Author

<!--Remove the below lines and add yours -->

[GitHub](https://github.com/jmeyu)
