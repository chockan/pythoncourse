import matplotlib.pyplot as plt
import matplotlib.image as img
img = img.imread("Finding_Lanes/picture.jpg")
plt.imshow(img)
plt.show()
