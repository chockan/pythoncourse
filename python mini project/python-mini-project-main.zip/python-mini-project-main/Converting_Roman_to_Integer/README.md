Fixed issue #73, Convert Roman to Integer.
CLI python 3.10 script to convert the Roman to Integer.
