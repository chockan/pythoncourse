# Math Game
It's just a simple math game. Improve your math skills

## Library used
`import random` and `import operator`

## How to run the script
`python math_game.py`

## Screenshot
<div align="center"><img src="https://github.com/xNewz/python-mini-projects/blob/master/projects/Math%20Game/img.gif"></div>

## *Author Name*
[`Pargorn Ruasijan (xNewz)`](https://github.com/xNewz)