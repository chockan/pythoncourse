<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)


# Email Slicer


<!--An image is an illustration for your project, the tip here is using your sense of humour as much as you can :D 

You can copy paste my markdown photo insert as following: 
<p align="center">
<img src = "" width="40%" height="40%">
-->

## 🛠️ Description
<!--Remove the below lines and add yours -->
Email Slicer separates username and domain from the given email address.

## ⚙️ Languages or Frameworks Used
<!--Remove the below lines and add yours -->
Language used is Python. There are no dependencies.

## 🌟 How to run
<!--Remove the below lines and add yours -->
It is really simple to run the program. Simple head over to the directory where python file is saved and run the following command:
```python3 EmailSlicer.py```

## 📺 Demo
![Screenshot from 2021-10-02 15-20-43](https://user-images.githubusercontent.com/68545365/135711432-f9cac4e1-ba34-44da-ac56-3b867710fa71.png)

## 🤖 Author
<!--Remove the below lines and add yours -->
<a href="https://github.com/ShrutiSolani">Shruti Solani

