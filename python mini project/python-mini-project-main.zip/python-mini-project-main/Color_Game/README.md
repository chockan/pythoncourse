# COLOR GAME
_**Mechanics:**_ 
* You must enter the color of the word, not the text itself.
* You have 30 seconds to play every round.    
* The highest score will be recorded in the .txt file.
