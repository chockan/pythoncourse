<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# Port Scanner 

## 🛠️ Description
<!--Remove the below lines and add yours -->
It's a simple port scanner.

## ⚙️ Languages or Frameworks Used
The program was created with Python3.

## 🌟 How to run
<!--Remove the below lines and add yours -->
* Clone the Project
* Run ```python scan_port.py```


## 🤖 Author
[AniYengibaryan](https://github.com/AniYengibaryan)

