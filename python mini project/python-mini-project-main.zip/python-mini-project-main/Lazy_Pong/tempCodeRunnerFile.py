Pushed a my first ever PyGame program which is  a Pong game 

# issue-no

# - #### **Lazy Pong** 

# - #### **A pong game at its Simplest form. Was challenge to do this in 1 hour with having little to no knowledge in pygame. So this is its first version that I will try to update in the following days since I'm on a 100 days coding challenge** 

# # Checklist:
# Please tick all the boxes that are fulfilled by your Pull Request.

# - [✔ ] I have named my files and folder, according to this project's guidelines.
# - [ ✔] My code follows the style guidelines of this project.
# - [✔ ] I have commented on my code, particularly in hard-to-understand areas.
# - [✔ ] I have created a helpful and easy to understand `README.md`, according to the given [`README_TEMPLATE.`](https://github.com/nduongthucanh/python-mini-project/blob/master/README_TEMPLATE.md)
# - [ ✔] My changes do not produce any warnings.
