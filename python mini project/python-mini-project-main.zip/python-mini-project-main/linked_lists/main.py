from doubly_linked_list import _DoublyLinkedList
from linked_deque import LinkedDeque
from linked_queue import  LinkedQueue
from linked_stack import LinkedStack

def main():
    my_linked_deque = LinkedDeque()
    my_linked_queue = LinkedQueue()
    my_linked_stack = LinkedStack()

