# Linked Lists

Implementation of various data structures using linked list.

## Languages or Frameworks used 

The programs are created with Python3


## How to run

`python3 ./main.py` to initilize all data structures. You can use the structures in this file.

## Author

[Diwas Dahal](https://github.com/di-was)