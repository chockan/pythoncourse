<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# Download Audio


<!--An image is an illustration for your project, the tip here is using your sense of humour as much as you can :D 

You can copy paste my markdown photo insert as following:
<p align="center">
<img src="your-source-is-here" width=40% height=40%>
-->

## 🛠️ Description
<!--Remove the below lines and add yours -->
This is a python script that downloads audio files directly from youtube videos.

## ⚙️ Languages or Frameworks Used
<!--Remove the below lines and add yours -->
This script is written in Python language. So make sure you have python installed in your computer. Two modules of python are used in this script to install those follow below steps
1. Open cmd prompt
2. write "pip install moviepy"
3. write "pip install pytube" 
## 🌟 How to run
<!--Remove the below lines and add yours -->
- Open the Download Audio.py script
- Add your own youtube video url instead of the default one in line 6.
- In Line 17, in the path section write your own path and in name section write the name You want your file to have.


## 🤖 Author
<!--Remove the below lines and add yours -->
### Name of Author: Muhammad Abdullah
Visit my Github profile [here](https://github.com/Muhammad-Abdullah3)

