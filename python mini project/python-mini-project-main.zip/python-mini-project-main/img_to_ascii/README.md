# Welcome to Image Comparator Tool 
This is a tool for converting an Image to ASCII art <br>

# Version
1.0.0

# Motivation and Description
We.Contribute -> You.Levegage ; You.Contribute -> We.Leverage ; All -> Grow

# Languages and Libraries used
Python and pywhatkit<br>

Installation
====================
Deploy the folder structure to the required location.

Execution
====================
Call python3 img_to_ascii.py.
  
# FAQ
mail us - acharjeerishi99@gmail.com 

	
