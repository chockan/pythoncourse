
# Spam Bot >>
    This is just a mini spam bot, you can used to prank friends, here i added 2 bots 
        1] bot1 -> which deals only one message until you clicked "q" to stop
        2] bot2 -> this one is little different it actully send word by word from provided paragraph

### Prerequisites
    nothig just check requirement.txt in this folder

### How to run the script
    windows : just click on run 
    linux : use this command -> python3 bot1.py


## *Author Name*

[Prafull Sonawane](https://github.com/prafuel)