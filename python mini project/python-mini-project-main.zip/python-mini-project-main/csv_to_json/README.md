<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# CSV TO JSON

## 🛠️ Description
<!--Remove the below lines and add yours -->
This script helps to convert a csv file to a json file.

## ⚙️ Languages or Frameworks Used
<!--Remove the below lines and add yours -->
language used - python3.
Packages required - csv and json.
if not already installed use pip3 install csv and pip3 install json.
(If there are a lot of them, including a `requirements.txt` file will work better.)

## 🌟 How to run
<!--Remove the below lines and add yours -->
python3 csv_to_json.py.



## 🤖 Author
<!--Remove the below lines and add yours -->
Rajit Gupta.
