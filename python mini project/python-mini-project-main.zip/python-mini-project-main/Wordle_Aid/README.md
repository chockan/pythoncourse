<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# Script Title


<p align="center">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Wordle_screenshot_2.png/256px-Wordle_screenshot_2.png" width=40% height=40%>



<!--An image is an illustration for your project, the tip here is using your sense of humour as much as you can :D 

You can copy paste my markdown photo insert as following:
<p align="center">
<img src="your-source-is-here" width=40% height=40%>
-->


## 🛠️ Description
<!--Remove the below lines and add yours -->
Use this to give you all the possible options for today's wordle based on the information available.

## ⚙️ Languages or Frameworks Used
<!--Remove the below lines and add yours -->
Python, import time

## 🌟 How to run
<!--Remove the below lines and add yours -->
Hit the run button with wordle open in a different window or on a different device. Once you make a guess, enter your guess and the colors in order (yellow, green, or gray)

## 📺 Demo
<p align="center">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wordle_demo.png/512px-Wordle_demo.png" width=40% height=40%>

/Documents/GitHub/python-mini-project/Wordle_Aid/Wordle_demo.png

## 🤖 Author
<!--Remove the below lines and add yours -->
Timmy Churchill
LinkedIn: https://www.linkedin.com/in/timothychurchill-/
Github: https://github.com/Timmy-Churchill


