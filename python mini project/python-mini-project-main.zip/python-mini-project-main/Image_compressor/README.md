<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# Image Compressor

## 🛠️ Description
<!--Remove the below lines and add yours -->
The image resizer takes in an image and reduces it's disk size according to the quality you choose, the compressed image is saved in the folder of the orignal image



## ⚙️ Languages or Frameworks Used
<!--Remove the below lines and add yours -->
Modules required to be able to use the script successfully
`pillow`, `os`, `easygui`

These modules are listed in `requirements.txt` and can be installed by running the following command `pip install requirements.txt`

## 🌟 How to run
<!--Remove the below lines and add yours -->
:Simply run the script


## 🤖 Author
<!--Remove the below lines and add yours -->
If you have any doubts or tips feel free to ping me on discord
dumb_potato#1734

