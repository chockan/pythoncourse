import os

def shutdown():
    os.system("shutdown /s /t 0")

shutdown()
