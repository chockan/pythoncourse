# Store all the answers of the questions in answer_bank dictionary
def answer(num):
    answer_bank = {
        1: "International Civil Aviation Organization",
        2: "China",
        3: "Camel",
        4: "1000",
        5: "Mars",
        6: "Elon Musk",
        7: "Helsinki",
        8: "Leonardo da Vinci",
        9: "Russia",
        10: "4",
        11: "Hazelnut",
        12: "118",
        13: "0",
        14: "All Clear",
        15: "Burj Khalifa",
        16: "Shark",
    }

    return answer_bank[num]
