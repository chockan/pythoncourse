<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# Script Title
Multiple Images To Pdf Converter

## 🛠️ Description
<!--Remove the below lines and add yours -->
Multiple images in Folder being converted in one pdf

## ⚙️ Languages or Frameworks Used
<!--Remove the below lines and add yours -->
Language used is Python. There are no dependencies.

## 🌟 How to run
<!--Remove the below lines and add yours -->
It is really simple to run the program. Simple head over to the directory where python file is saved and run the following 
command: python3 images_to_pdf.py

## 🤖 Author
<!--Remove the below lines and add yours -->
Nikhil Gupta