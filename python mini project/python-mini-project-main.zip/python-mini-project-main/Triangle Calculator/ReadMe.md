## Why am I doing this
I am a software engineering student that just started learning GitHub and want to familiar with the GitHub Contribution Function

## Description
This is a simple program that calculate the area of the triangle

## How to run
Open a terminal in the folder where script is located and run the following command:

```sh
python TriangleCalculator.py
```

Then input every side of the triangle and it will output the area of the triangle :)

## Author
Benny Kwan