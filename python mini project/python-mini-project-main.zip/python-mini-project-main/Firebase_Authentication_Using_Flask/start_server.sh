source .env
python run.py