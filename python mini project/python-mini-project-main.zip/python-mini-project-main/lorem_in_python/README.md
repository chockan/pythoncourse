# Lorem Generator >>
    You have already used lorem funtion in html file in vscode to generate some nonsense text here is just same version but in python..

### Prerequisites
    nothig just need python install locally.....

### How to run the script
    windows : just click on run 
    linux : use this command -> python3 <name_of_file.py>


## *Author Name*

[Prafull Sonawane](https://github.com/prafuel)