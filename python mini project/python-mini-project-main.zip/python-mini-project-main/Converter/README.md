<!--Please do not remove this part-->
![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

# Converter

<p align="center">
<img src="https://github.com/AlenSenson/python-mini-project/blob/main/Converter/images.png" width=20% height=20%>


## 🛠️ Description
A simple converter app built in python.

## ⚙️ Languages or Frameworks Used
You only need Python to run this script. You can visit here to download Python.

## 🌟 How to run
Running the script is really simple! Just open a terminal in the folder where your script is located and run the following command:

```sh
python converter.py
```

## 📺 Demo
<p align="center">
<img src="https://github.com/AlenSenson/python-mini-project/blob/main/Converter/Screenshot%202023-05-31%20180831.png" width=70% height=70%>

## 🤖 Author
[Alen Senson](https://github.com/AlenSenson)
