# Script Title
A program that allows the user to convert the text he/she inputs into the program into a voice audio that is played in real time.

### Prerequisites
tkinter and pyttsx3 is required for this

install pyttsx3: pip install pyttsx3
tkinter should come pre installed with python

### How to run the script
Just run the python file

### Screenshot/GIF showing the sample use of the script
image.png

## *Author Name*
BlockmasterPlayz