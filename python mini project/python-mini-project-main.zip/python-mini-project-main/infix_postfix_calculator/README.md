# Python Infix/Postfix Calculator
 
<img width="412" alt="Picture" src="https://user-images.githubusercontent.com/50146617/208979333-258f9c81-154f-4b71-a9b0-b82f293f810e.png">