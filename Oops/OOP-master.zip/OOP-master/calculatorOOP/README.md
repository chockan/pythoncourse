# Calculator Project 

This program requires user input to select two integers and the appropriate operator to carry out the operation. 

**Entering first and second numbers:**

```bash
Enter first number:
Enter second number:
```

**Selecting the operator:**

```bash
 Please select one of the following: 
            =======================================
            + for addition
            - for subtraction 
            * for multiplication 
            / for division
            % for modulus
            tr to find the area of a triangle
            in to convert cm_to_inches 
            cm to convert inches_to_cm 
            0 to exit
            ========================================
            Please enter your chosen operator:
```