class Person:

    @staticmethod
    def sleep():
        return "sleeping..."
