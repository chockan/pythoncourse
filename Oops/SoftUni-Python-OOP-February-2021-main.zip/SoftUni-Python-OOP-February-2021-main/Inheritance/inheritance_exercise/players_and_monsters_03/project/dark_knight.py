from Inheritance.inheritance_exercise.players_and_monsters_03.project.knight import Knight
# from project.knight import Knight


class DarkKnight(Knight):
    pass
