from Inheritance.inheritance_exercise.players_and_monsters_03.project.dark_wizard import DarkWizard
# from project.dark_wizard import DarkWizard


class SoulMaster(DarkWizard):
    pass
