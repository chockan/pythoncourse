from Inheritance.inheritance_exercise.players_and_monsters_03.project.dark_knight import DarkKnight
# from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    pass
