from Inheritance.inheritance_exercise.players_and_monsters_03.project.wizard import Wizard
# from project.wizard import Wizard


class DarkWizard(Wizard):
    pass
