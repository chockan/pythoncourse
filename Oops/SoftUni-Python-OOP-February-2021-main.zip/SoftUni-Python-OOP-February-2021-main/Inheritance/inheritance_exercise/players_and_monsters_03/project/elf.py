from Inheritance.inheritance_exercise.players_and_monsters_03.project.hero import Hero
# from project.hero import Hero


class Elf(Hero):
    pass
