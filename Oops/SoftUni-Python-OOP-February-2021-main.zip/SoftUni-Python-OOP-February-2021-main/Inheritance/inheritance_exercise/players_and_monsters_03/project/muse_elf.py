from Inheritance.inheritance_exercise.players_and_monsters_03.project.elf import Elf
# from project.elf import Elf


class MuseElf(Elf):
    pass
