from Inheritance.inheritance_exercise.zoo_02.project.reptile import Reptile
# from project.reptile import Reptile


class Lizard(Reptile):
    pass
