from Inheritance.inheritance_exercise.zoo_02.project.mammal import Mammal
# from project.mammal import Mammal


class Bear(Mammal):
    pass
