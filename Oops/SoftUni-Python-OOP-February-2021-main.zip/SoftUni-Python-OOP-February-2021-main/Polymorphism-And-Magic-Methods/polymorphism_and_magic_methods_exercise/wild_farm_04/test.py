from PolymorphismAndMagicMethods.polymorphism_and_magic_methods_exercise.wild_farm_04.project.food import \
    Vegetable, Fruit, Meat

from PolymorphismAndMagicMethods.polymorphism_and_magic_methods_exercise.wild_farm_04.project.animals.birds import \
    Owl, Hen
from PolymorphismAndMagicMethods.polymorphism_and_magic_methods_exercise.wild_farm_04.project.animals.mammals import \
    Tiger

owl = Owl("Pip", 10, 10)
print(owl.__dict__)
# print(owl)
# meat = Meat(4)
# print(owl.make_sound())
# owl.feed(meat)
# veg = Vegetable(1)
# print(owl.feed(veg))
# print(owl)
#
# print("-------------")
#
# hen = Hen("Harry", 10, 10)
# veg = Vegetable(3)
# fruit = Fruit(5)
# meat = Meat(1)
# print(hen)
# print(hen.make_sound())
# hen.feed(veg)
# hen.feed(fruit)
# hen.feed(meat)
# print(hen)
#
# print("-------------")
#
# tiger = Tiger("Harry", 10, 10)
# veg = Vegetable(3)
# fruit = Fruit(5)
# meat = Meat(1)
# print(meat.quantity)
# print(tiger)
# print(tiger.make_sound())
# print(tiger.feed(veg))
# print(tiger.feed(fruit))
# print(tiger.feed(meat))
# print(tiger)
