print("I am\nAvik") # \n means new line

print("Python is ", end = "") # default line break is no more
print("FUN")

print("Python is", end = " ")
print("FUN")

print("Python is ", end = "SUPER ")
print("FUN")
