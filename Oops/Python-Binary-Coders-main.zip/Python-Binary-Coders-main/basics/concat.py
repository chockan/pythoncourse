str1 = "Good"
str2 = "Bye"

print(str1 + str2)
print(str1 + " " + str2)
''' more ways to do the same

print(str1 + ' ' + str2)
print(str1 + ''' ''' + str2)

'''
