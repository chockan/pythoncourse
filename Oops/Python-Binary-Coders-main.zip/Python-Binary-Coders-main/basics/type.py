x = 5 # integer
y = 5.43 # float
z = "BCD_123@" # string
b = True # boolean

# print the type of variable
print(type(x))
print(type(y))
print(type(z))
print(type(b))