# example of comments

print("Hello") # it prints in the console
print('Bye')

'''
Hey
It's a comment
'''

# triple quotes provide support for multiline
print('''Good
Boy
    Girl''')

print(12)
