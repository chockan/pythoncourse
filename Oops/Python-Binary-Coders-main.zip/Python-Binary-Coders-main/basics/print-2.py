x = 404 # int

print("Value of x is " + str(x))
# in case of comma, type doesn't matter
print("Value of x is", x) # by deafult a blank space in between
# f string
print(f"Value of x is {x}") # variable inside ' { } ' gets replaced with its value
