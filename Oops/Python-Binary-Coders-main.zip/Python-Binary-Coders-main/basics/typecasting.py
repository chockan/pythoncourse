x = 5
y = float(x) # typecasting is applied

print(type(x)) # datatype of x is unchanged
print(type(y))

print(x)
print(y)

m = 3.67
z = int(m) # typecasting is applied

print(z)
