# print("Enter a number:")
# x = input()
# x = int(x)
x = int(input("Enter a number:")) # taking input and typecasting to int as by default the input function takes input in the form of STRING

print(type(x)) # int
print(x + 2)
