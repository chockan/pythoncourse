x = 5 # integer
y = 5.43 # floating point number (float)
z = "BCD_123@" # string
m = 'T' # string
b = True # boolean
f = False # boolean

print(x, y, z, m, b, f)

m = 12 # this will override the previous value of m

print(m)
