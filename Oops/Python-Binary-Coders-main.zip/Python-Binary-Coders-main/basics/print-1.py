print("Hello")
print('Bye')
print('''Good''')
print(12)
